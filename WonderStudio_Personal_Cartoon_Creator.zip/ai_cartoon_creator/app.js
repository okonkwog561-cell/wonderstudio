const $ = (id) => document.getElementById(id);
let latestPlan = "";
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function makePlan(){
 const topic=$('topic').value.trim() || 'Three friends discover a surprising mystery and solve it together';
 const lesson=$('lesson').value, chars=$('characters').value, style=$('style').value, length=$('length').value, format=$('format').value;
 const notes=$('characterNotes').value.trim();
 const cleanTopic=topic.replace(/[.!?]+$/,'');
 const title = cleanTopic.length < 48 ? cleanTopic.replace(/^./,c=>c.toUpperCase()) : 'The Little Mystery of Friendship';
 const scenes=[
  ['A curious beginning','Show the characters in a bright, welcoming place. One notices something unusual connected to: '+cleanTopic+'.','Wide establishing shot; gentle camera move; curious music.'],
  ['The question','The friends react in different ways. One wants to act quickly, another asks them to look carefully and think.','Close-ups of each original character; expressive gestures.'],
  ['Clues and teamwork','Each friend notices a different clue. They listen, share ideas, and combine what they know.','Three short shots, one for each clue; keep clothing and character features consistent.'],
  ['The discovery','Together, the friends solve the mystery. Reveal a new, original surprise that fits the topic without copying the reference video.','Build anticipation, then reveal the surprise in a colourful shot.'],
  ['A warm ending','The friends celebrate and explain how the experience showed them '+lesson.toLowerCase()+'. End with a friendly wave and a question for viewers.','Happy group shot; title card; original licensed or self-created music.']
 ];
 const script=[
  'NARRATOR: Every great adventure begins with a little curiosity.',
  'CHARACTER 1: “Did you see that? Something unusual is happening!”',
  'CHARACTER 2: “Let’s slow down and find out what it means.”',
  'CHARACTER 3: “I noticed something too. What if we put our clues together?”',
  'NARRATOR: Each friend shared an idea. Little by little, the mystery became clear.',
  'CHARACTER 1: “We did it together!”',
  `CHARACTER 2: “Today we learned about ${lesson.toLowerCase()}. Everyone had something important to contribute.”`,
  'NARRATOR: And that was only the beginning of their next adventure. What would you have done?'
 ];
 let html=`<div class="script-block"><h3>Story concept</h3><p>${esc(title)} follows ${esc(chars)} as they explore an original adventure about ${esc(cleanTopic)}. The central takeaway is ${esc(lesson.toLowerCase())}.</p><p><strong>Character notes:</strong> ${esc(notes||'Create a consistent model sheet for each character: colours, outfit, face, proportions, personality, and voice.')}</p><p><strong>Style:</strong> ${esc(style)} · <strong>Length:</strong> ${esc(length)} · <strong>Format:</strong> ${esc(format)}</p></div>`;
 html+='<div class="script-block"><h3>Draft narration and dialogue</h3>'+script.map(x=>`<p>${esc(x)}</p>`).join('')+'</div>';
 html+='<div class="script-block"><h3>Scene-by-scene storyboard</h3>'+scenes.map((s,i)=>`<div class="scene"><strong>Scene ${i+1}: ${esc(s[0])}</strong><p><b>Action:</b> ${esc(s[1])}</p><p><b>Visual direction:</b> ${esc(s[2])}</p></div>`).join('')+'</div>';
 html+='<div class="script-block"><h3>Before publishing</h3><p>Write fresh dialogue and create your own assets. Do not reuse the reference video’s footage, soundtrack, thumbnail, script, or distinctive characters without permission. Check factual claims, captions, audio rights, and platform rules. Add a meaningful original contribution rather than mass-producing near-identical videos.</p></div>';
 $('storyTitle').textContent=title; $('meta').textContent=`${length} · ${style} · Created locally`;
 $('storyOutput').innerHTML=html; $('output').classList.remove('hidden');
 latestPlan=`${title}\n\nTopic: ${topic}\nLesson: ${lesson}\nCharacters: ${chars}\nStyle: ${style}\nLength: ${length}\nFormat: ${format}\nReference URL: ${$('url').value.trim()}\n\n${script.join('\n\n')}\n\nSTORYBOARD\n`+scenes.map((s,i)=>`Scene ${i+1}: ${s[0]}\nAction: ${s[1]}\nVisual direction: ${s[2]}`).join('\n\n')+`\n\nCharacter notes: ${notes}`;
}
$('generate').addEventListener('click',makePlan);
$('copy').addEventListener('click',async()=>{if(!latestPlan)return;try{await navigator.clipboard.writeText(latestPlan);$('copy').textContent='Copied!';setTimeout(()=>$('copy').textContent='Copy plan',1500)}catch(e){fallbackCopy(latestPlan)}});
function fallbackCopy(text){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();$('copy').textContent='Copied';}
$('download').addEventListener('click',()=>{if(!latestPlan)return;const blob=new Blob([latestPlan],{type:'text/plain;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='wonderstudio-video-plan.txt';a.click();URL.revokeObjectURL(a.href)});
$('save').addEventListener('click',()=>{if(!latestPlan)return;try{localStorage.setItem('wonderstudioPlan',latestPlan);$('save').textContent='Saved in browser';setTimeout(()=>$('save').textContent='Save in this browser',1500)}catch(e){alert('Browser storage is unavailable. Please download your plan instead.')}});
